/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Vista.FRM_MenuPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author braghoick
 */



public class Controlador_FRM_MenuPrincipal implements ActionListener{

    
    FRM_MenuPrincipal fRM_MenuPrincipal;

    public Controlador_FRM_MenuPrincipal(FRM_MenuPrincipal fRM_MenuPrincipal) {
        this.fRM_MenuPrincipal = fRM_MenuPrincipal;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
